<!DOCTYPE html>
<h2 align="center">
<hr>
🚀 Autoscript SSH XRAY Websocket Multiport By Vinstechmy (FREE!)🚀
<h2><hr>
  
<h2 align="center"> ♦️Supported Linux Distribution♦️</h2>
</p>
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=blue"> <br>
<img src="https://img.shields.io/badge/Service-Multiport (XRAY)-orange"></p>

## ⚠️ PLEASE README ⚠️
<b>
 AUTOSCRIPT WEBSOCKET MULTIPORT INI SESUAI UNTUK TRICK MERAH - KUNING - BIRU (MALAYSIA) <br>
 <br>
 1. LINK CONFIG SIAP GENERATE UNTUK TELCO MERAH - KUNING - BIRU (MALAYSIA) <br>
 2. JIKA TERDAPAT SEBARANG BUG / GLITCH BOLEH LAPORKAN PADA SAYA DI TELEGRAM : @Vinstechmy <br>
 <br>
 
 SILA PASTIKAN SETTING DOMAIN DI CLOUDFLARE ANDA SEPERTI DIBAWAH (SSL/TLS SETTINGS) <br>
 ![image](https://user-images.githubusercontent.com/82468311/191471897-986ebe25-5330-4997-8a44-5468b422482a.png) <br>

![image](https://user-images.githubusercontent.com/82468311/191472903-b55cd39a-8909-4f7c-b3ad-013cb3c91282.png)

<br>
</b>
  
## ⏩ AUTOSCRIPT WEBSOCKET MULTIPORT DETAILS ⏪
<b>
[ XRAY SERVICES ] <br>
<br>
✅ SSH WEBSOCKET TLS & NON-TLS <br>
✅ XRAY VMESS WEBSOCKET TLS & NON-TLS <br>
✅ XRAY VLESS WEBSOCKET TLS & NON-TLS <br>
✅ XRAY TROJAN WEBSOCKET TLS & NON-TLS <br>
<br>
[ OTHER SERVICES ] <br>
<br>
✅ YAML LINK <br>
✅ AUTOSCRIPT UPDATER <br>
✅ BANDWITH MONITOR <br>
✅ DNS CHANGER <br>
✅ NETFLIX REGION CHECKER <br>
✅ CHECK LOGIN USER <br>
✅ CHECK CREATED CONFIG <br>
✅ AUTOMATIC CLEAR LOG <br>
✅ AUTOMATIC VPS REBOOT <br>
✅ BACKUP & RESTORE <br>
<br>
<br>
♦️ For Debian 10 Only For First Time Installation <br>
<br>
  
  ```html
 apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot
  ```

♦️ Installation Link<br>

  ```html
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/vinstechmy/SSH-XRAY-Websocket-Multiport/main/V1/setup-lite.sh && chmod +x setup-lite.sh && ./setup-lite.sh
  ```

</b>

## ⏩ AUTOSCRIPT WEBSOCKET MULTIPORT EXAMPLE ⏪
<b>
</b>
<br>

</b>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/199133400-0c09cb98-04bd-45ca-a362-b7aee2bb27cf.png" width="400" title="Autoscript-Lite">
</p>

</b>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/191024199-5c324236-54d1-458a-8920-9f03621d1e10.png" width="400" title="Autoscript-Lite">
</p>

## ⏩ BUY ME A COFFEE ? ⏪
<b>
<br>
<p align="center">
<img src="https://user-images.githubusercontent.com/82468311/189573622-9b165a67-4ae7-4354-bd8d-5fad54c266fa.JPG" width="300" title="Autoscript-Lite">
<b>
